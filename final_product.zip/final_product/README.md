# Før du køyrer programmet må du ha følgande biblioteker
- **numpy**
- **pandas**
- **matplotlib**
- **seaborn**
- **scikit-learn**
- **xgboost**
- **lightgbm**
- **catboost**

Dersom desse manglar kan instasller de slik: pip instsall catboost xgboost pandas osv..

## 1. Pakkut ZIP filen
## 2. Naviger til mappen i terminal (cmd, anaconda, powershell)
## 3. Køyr main med: python main.py

